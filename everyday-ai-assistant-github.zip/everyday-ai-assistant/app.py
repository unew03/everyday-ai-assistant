import os
import streamlit as st
from anthropic import Anthropic
from dotenv import load_dotenv

load_dotenv()
st.set_page_config(page_title="Everyday AI Assistant", page_icon="🤖")
st.title("🤖 Everyday AI Assistant")
st.caption("A simple chat interface powered by Claude.")

api_key = os.getenv("ANTHROPIC_API_KEY")
if not api_key:
    st.info("Create a .env file and add your Anthropic API key:")
    st.code("ANTHROPIC_API_KEY=your_api_key_here")
    st.stop()

client = Anthropic(api_key=api_key)
if "messages" not in st.session_state:
    st.session_state.messages = []

with st.sidebar:
    model = st.selectbox("Model", ["claude-sonnet-4-5", "claude-haiku-4-5"])
    max_tokens = st.slider("Maximum response tokens", 256, 4096, 1200, 256)
    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()

for item in st.session_state.messages:
    with st.chat_message(item["role"]):
        st.markdown(item["content"])

prompt = st.chat_input("Ask Claude something…")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    with st.chat_message("assistant"):
        try:
            response = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system="You are a helpful, clear, and honest general-purpose assistant.",
                messages=st.session_state.messages,
            )
            answer = "\n".join(
                block.text for block in response.content
                if getattr(block, "type", None) == "text"
            ).strip()
            st.markdown(answer or "_No text response returned._")
            st.session_state.messages.append(
                {"role": "assistant", "content": answer}
            )
        except Exception as exc:
            st.error("The request failed. Check your API key, model access, and connection.")
            st.caption(f"{type(exc).__name__}: {exc}")
