# Everyday AI Assistant

A beginner-friendly chat application built with Python, Streamlit, and Anthropic's Claude API.

## Features
- Browser-based chat interface
- Claude model selection
- Adjustable response length
- Conversation history during the current session
- Local environment-variable API key configuration

## Requirements
- Python 3.10+
- An Anthropic API key with API access

**Billing note:** Claude Pro and Anthropic API usage are separate. This app requires an API key and API usage may incur charges; a Pro subscription alone does not provide API credits.

## Run locally
1. Clone this repository and enter its directory.
2. Create a virtual environment: `python -m venv .venv`
3. Activate it (`source .venv/bin/activate` on macOS/Linux).
4. Install dependencies: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` and add your API key.
6. Run: `streamlit run app.py`

## Security
Never commit `.env`, API keys, or credentials. The included `.gitignore` excludes local secrets.

## Ideas for future work
- Automated tests and continuous integration
- Streaming responses
- Conversation export
- Custom system prompts
- Accessibility and mobile-layout improvements

## Project status
Starter implementation / early-stage personal project. Update this README as you add features, tests, screenshots, and real usage information.

## License
MIT. See [LICENSE](LICENSE).
